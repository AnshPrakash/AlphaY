#!/bin/bash

python training.py 